package reactive.demo;

import org.reactivestreams.Publisher;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

public class FluxMonoGeneratorService {

    //flux -> o to n reactive stream
    //Mono -> o or 1 reactive stream
    public Flux<String> namesFlux() {
        return Flux.fromIterable(List.of("john", "peter"))
                .map(name -> name.toUpperCase())
                .filter(name -> name.length() > 3)
                .flatMap(name -> splitStr(name));
    }

    // flux -> name -> flux [flux ] -> flatmap -> flux
    private Flux<String> splitStr(String name) {
        return Flux.fromArray(name.split(""));
    }

    // [[1,2,[5,6]],[3,4]] -> [1,2,5,6,3,4]
    public Mono<String> nameMono() {
        return Mono.just("zack").log();
    }

    public static void main(String[] args) {
        FluxMonoGeneratorService fluxMonoGeneratorService = new FluxMonoGeneratorService();
        fluxMonoGeneratorService.namesFlux()
                .subscribe(name -> System.out.println(name));

//        fluxMonoGeneratorService.nameMono()
//                .subscribe(name -> System.out.println(name));
    }
}
