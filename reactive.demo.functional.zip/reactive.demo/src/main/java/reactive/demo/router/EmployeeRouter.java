package reactive.demo.router;

import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactive.demo.handler.EmployeeHandler;

import static org.springframework.web.reactive.function.server.RequestPredicates.accept;

@Configuration
@AllArgsConstructor
public class EmployeeRouter {
    private EmployeeHandler employeeHandler;

    public RouterFunction<ServerResponse> employeeRoutes() {
        RouterFunction<ServerResponse> routerFunction = RouterFunctions.route()
                .path("/api/employees", builder -> builder
                        .POST("", accept(MediaType.APPLICATION_JSON), employeeHandler::saveEmployee)
                        .GET("/{id}", accept(MediaType.APPLICATION_JSON), employeeHandler::getEmployee)
                        .GET("", accept(MediaType.APPLICATION_JSON), employeeHandler::getAllEmployees)
                        .PUT("/{id}", accept(MediaType.APPLICATION_JSON), employeeHandler::updateEmployee)
                        .DELETE("/{id}", accept(MediaType.APPLICATION_JSON), employeeHandler::deleteEmployee)
                )
                .build();
        return routerFunction;
    }
}
