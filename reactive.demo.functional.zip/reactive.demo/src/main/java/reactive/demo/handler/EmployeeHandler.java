package reactive.demo.handler;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactive.demo.dto.EmployeeDto;
import reactive.demo.entity.Employee;
import reactive.demo.service.EmployeeService;
import reactor.core.publisher.Mono;

@Component
@AllArgsConstructor
public class EmployeeHandler {
    //functional way of implementing reactive stream

    private EmployeeService employeeService;


    public Mono<ServerResponse> saveEmployee(ServerRequest request) {
        Mono<ServerResponse> serverResponse = request
                .bodyToMono(EmployeeDto.class)
                .flatMap(employeeDto -> employeeService.saveEmployee(employeeDto))
                .flatMap(employeeDto -> ServerResponse.status(HttpStatus.CREATED).bodyValue(employeeDto));

        return serverResponse;
    }

    public Mono<ServerResponse> getEmployee(ServerRequest request) {

        String employeeId = request.pathVariable("id");
        Mono<ServerResponse> serverResponse = employeeService.getEmployee(employeeId)
                .flatMap(employeeDto -> ServerResponse.ok().bodyValue(employeeDto))
                .switchIfEmpty(ServerResponse.notFound().build());

        return serverResponse;
    }

    public Mono<ServerResponse> getAllEmployees(ServerRequest request) {
        Mono<ServerResponse> serverResponse = employeeService
                .getAllEmployees().collectList()
                .flatMap(employeeDtos -> ServerResponse.ok().bodyValue(employeeDtos));
        return serverResponse;
    }

    public Mono<ServerResponse> updateEmployee(ServerRequest request){
        String employeeId = request.pathVariable("id");
        Mono<ServerResponse> serverResponse = request
                .bodyToMono(EmployeeDto.class)
                .flatMap(employeeDto -> employeeService.updateEmployee(employeeDto,employeeId))
                .flatMap(employeeDto -> ServerResponse.ok().bodyValue(employeeDto));
        return serverResponse;
    }

    public Mono<ServerResponse> deleteEmployee(ServerRequest request){
        String employeeId = request.pathVariable("id");
        Mono<ServerResponse> serverResponse = employeeService
                .deleteEmployee(employeeId)
                .then(ServerResponse.noContent().build());
        return serverResponse;
    }

}

// Service Side Event or SSE (spring webflux)