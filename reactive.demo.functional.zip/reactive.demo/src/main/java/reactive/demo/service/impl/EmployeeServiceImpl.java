package reactive.demo.service.impl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import reactive.demo.dto.EmployeeDto;
import reactive.demo.entity.Employee;
import reactive.demo.mapper.EmployeeMapper;
import reactive.demo.repository.EmployeeRepository;
import reactive.demo.service.EmployeeService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;

    @Override
    public Mono<EmployeeDto> saveEmployee(EmployeeDto employeeDto) {
        // dto -> mapper -> entity -> save -> return dto

        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);
        Mono<Employee> savedEmployee = employeeRepository.save(employee);

        return savedEmployee
                .map(employeeEntity -> EmployeeMapper.mapToEmployeeDto(employeeEntity));
    }

    @Override
    public Mono<EmployeeDto> getEmployee(String employeeId) {

        Mono<Employee> savedEmployee = employeeRepository.findById(employeeId);
        return savedEmployee
                .map(employee -> EmployeeMapper.mapToEmployeeDto(employee));
    }

    @Override
    public Flux<EmployeeDto> getAllEmployees() {
        Flux<Employee> employees = employeeRepository.findAll();
        return employees
                .map(employee -> EmployeeMapper.mapToEmployeeDto(employee));
    }

    @Override
    public Mono<EmployeeDto> updateEmployee(EmployeeDto employeeDto, String employeeId) {
        Mono<Employee> savedEmployee = employeeRepository.findById(employeeId);

        savedEmployee
                .flatMap(existingEmployee -> {
                    existingEmployee.setFirstName(employeeDto.getFirstName());
                    existingEmployee.setLastName(employeeDto.getLastName());
                    existingEmployee.setEmail(employeeDto.getEmail());
                    return employeeRepository.save(existingEmployee);
                });

        return savedEmployee
                .map(employee -> EmployeeMapper.mapToEmployeeDto(employee));
    }

    @Override
    public Mono<Void> deleteEmployee(String employeeId) {
        return employeeRepository.deleteById(employeeId);
    }
}
