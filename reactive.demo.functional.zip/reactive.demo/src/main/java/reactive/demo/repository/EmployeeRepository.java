package reactive.demo.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactive.demo.entity.Employee;

public interface EmployeeRepository extends ReactiveCrudRepository<Employee,String> {
}
